package com.jarvis.assistant.ui.home

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.LinearGradient
import android.graphics.Shader
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.snackbar.Snackbar
import com.jarvis.assistant.R
import com.jarvis.assistant.data.model.ConversationState
import com.jarvis.assistant.databinding.ActivityMainBinding
import com.jarvis.assistant.ui.chat.ChatHistoryBottomSheet
import com.jarvis.assistant.ui.orb.OrbHelper
import com.jarvis.assistant.ui.settings.SettingsActivity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var orbHelper: OrbHelper

    private val requestAudioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        val micGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (micGranted) {
            viewModel.toggleSession()
        } else {
            Toast.makeText(
                this,
                "Microphone permission is required for voice conversation.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupOrb()
        setupListeners()
        observeViewModel()
        styleTexts()
        playEntranceAnimation()
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshSettings()
    }

    // Gradient text for the "MADE BY AJ SIR" credit and the app title.
    private fun styleTexts() {
        applyGradientText(
            binding.tvMadeBy,
            ContextCompat.getColor(this, R.color.aj_gold_soft),
            ContextCompat.getColor(this, R.color.aj_gold)
        )
        applyGradientText(
            binding.tvJarvisTitle,
            ContextCompat.getColor(this, R.color.primary_cyan),
            ContextCompat.getColor(this, R.color.purple_glow)
        )
    }

    private fun applyGradientText(tv: TextView, startColor: Int, endColor: Int) {
        tv.post {
            val textWidth = tv.paint.measureText(tv.text.toString())
            tv.paint.shader = LinearGradient(
                0f, 0f, textWidth, 0f,
                intArrayOf(startColor, endColor),
                null,
                Shader.TileMode.CLAMP
            )
            tv.invalidate()
        }
    }

    // "07:32 PM" with a smaller AM/PM, like the HUD reference.
    private fun showClock(time: String) {
        val sp = SpannableString(time)
        val idx = time.indexOf(' ')
        if (idx > 0) {
            sp.setSpan(RelativeSizeSpan(0.32f), idx, time.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        binding.tvLiveTime.text = sp
    }

    private fun updateDateUi() {
        val now = Date()
        binding.tvDateNum.text = SimpleDateFormat("dd", Locale.ENGLISH).format(now)
        binding.tvDateMonth.text = SimpleDateFormat("MMM", Locale.ENGLISH).format(now).uppercase()
        binding.tvDateDay.text = SimpleDateFormat("EEEE", Locale.ENGLISH).format(now).uppercase()
    }

    private fun playEntranceAnimation() {
        val views: List<View> = listOf(
            binding.boxMadeBy,
            binding.topBar,
            binding.subInfoBar,
            binding.hudClockRow,
            binding.orbContainer,
            binding.boxState,
            binding.controlsLayout
        )
        views.forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationY = 24f
            view.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(index * 90L)
                .setDuration(550)
                .start()
        }
    }

    private fun setupOrb() {
        orbHelper = OrbHelper(binding.webViewOrb)
        orbHelper.setup()
    }

    private fun setupListeners() {
        binding.btnSettings.setOnClickListener {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }

        binding.btnPowerSession.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            val wanted = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE
            )
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                wanted.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            val missing = wanted.filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }
            if (missing.isEmpty() || viewModel.isSessionOn.value) {
                viewModel.toggleSession()
            } else {
                requestAudioPermissionLauncher.launch(missing.toTypedArray())
            }
        }

        binding.btnMicMute.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            viewModel.toggleMicMute()
        }

        binding.tvViewHistory.setOnClickListener {
            showChatHistory()
        }

        binding.boxJarvisTitle.setOnClickListener {
            showChatHistory()
        }
    }

    private fun showChatHistory() {
        ChatHistoryBottomSheet.newInstance().show(
            supportFragmentManager,
            ChatHistoryBottomSheet.TAG
        )
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.liveTime.collect { time ->
                        showClock(time)
                        updateDateUi()
                    }
                }

                launch {
                    viewModel.greeting.collect { greeting ->
                        binding.tvGreeting.text = greeting
                    }
                }

                launch {
                    viewModel.orbTheme.collect { theme ->
                        orbHelper.setTheme(theme)
                    }
                }

                launch {
                    viewModel.sessionSeconds.collect {
                        updateTimerUi()
                    }
                }

                launch {
                    viewModel.personalityName.collect { personality ->
                        binding.tvPersonalityMode.text = personality
                    }
                }

                launch {
                    viewModel.isSessionOn.collect { isOn ->
                        updatePowerButtonUi(isOn)
                    }
                }

                launch {
                    viewModel.isMicMuted.collect { isMuted ->
                        updateMicMuteUi(isMuted)
                    }
                }

                launch {
                    viewModel.conversationState.collect { state ->
                        updateConversationStateUi(state)
                    }
                }

                launch {
                    viewModel.audioLevel.collect { level ->
                        orbHelper.updateAudioLevel(level)
                    }
                }

                launch {
                    viewModel.connectionStatus.collect { status ->
                        updateConnectionStatusUi(status)
                    }
                }

                launch {
                    viewModel.eventFlow.collect { message ->
                        Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun updateTimerUi() {
        if (viewModel.isSessionOn.value) {
            val total = viewModel.sessionSeconds.value
            binding.tvSessionTimer.text = String.format("%02d:%02d", total / 60, total % 60)
            binding.tvSessionTimer.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
        } else {
            binding.tvSessionTimer.text = getString(R.string.hint_idle)
            binding.tvSessionTimer.setTextColor(ContextCompat.getColor(this, R.color.text_muted))
        }
    }

    private fun updatePowerButtonUi(isOn: Boolean) {
        // Keep the screen awake while a voice session is running.
        if (isOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        updateTimerUi()

        if (isOn) {
            binding.btnPowerSession.setBackgroundResource(R.drawable.bg_power_button)
            binding.ivPowerIcon.imageTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, R.color.primary_cyan)
            )
            binding.tvPowerText.text = getString(R.string.btn_on)
            binding.tvPowerText.setTextColor(
                ContextCompat.getColor(this, R.color.primary_cyan)
            )
        } else {
            binding.btnPowerSession.setBackgroundResource(R.drawable.bg_power_button_off)
            binding.ivPowerIcon.imageTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, R.color.text_muted)
            )
            binding.tvPowerText.text = getString(R.string.btn_off)
            binding.tvPowerText.setTextColor(
                ContextCompat.getColor(this, R.color.text_muted)
            )
        }
    }

    private fun updateMicMuteUi(isMuted: Boolean) {
        if (isMuted) {
            binding.btnMicMute.setImageResource(R.drawable.ic_mic_off)
            binding.btnMicMute.imageTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, R.color.status_red)
            )
        } else {
            binding.btnMicMute.setImageResource(R.drawable.ic_mic)
            binding.btnMicMute.imageTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, R.color.primary_cyan)
            )
        }
    }

    private fun updateConversationStateUi(state: ConversationState) {
        binding.tvConversationState.text = state.displayName
        val colorRes = when (state) {
            ConversationState.IDLE -> R.color.text_secondary
            ConversationState.LISTENING -> R.color.primary_cyan
            ConversationState.THINKING -> R.color.purple_glow
            ConversationState.SPEAKING -> R.color.neon_blue
        }
        binding.tvConversationState.setTextColor(ContextCompat.getColor(this, colorRes))
        orbHelper.updateState(state)
    }

    private fun updateConnectionStatusUi(status: String) {
        // Short labels so the pill never collides with the power button.
        binding.tvConnectionStatus.text = when (status) {
            "CONNECTING..." -> "CONNECTING"
            "RECONNECTING..." -> "RETRYING"
            else -> status
        }
        val dotColor = when (status) {
            "LIVE" -> ContextCompat.getColor(this, R.color.status_green)
            "CONNECTING...", "RECONNECTING..." -> ContextCompat.getColor(this, R.color.status_amber)
            else -> ContextCompat.getColor(this, R.color.text_muted)
        }
        binding.viewStatusDot.backgroundTintList = ColorStateList.valueOf(dotColor)
    }
}
