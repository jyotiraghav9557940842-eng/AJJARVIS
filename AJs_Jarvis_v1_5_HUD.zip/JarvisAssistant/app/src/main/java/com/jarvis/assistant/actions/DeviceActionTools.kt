package com.jarvis.assistant.actions

import com.jarvis.assistant.data.model.FunctionDeclarationPayload
import com.jarvis.assistant.data.model.ParamPropertyPayload
import com.jarvis.assistant.data.model.ParametersPayload
import com.jarvis.assistant.data.model.ToolPayload

/** Function declarations that Gemini Live can call to control the phone. */
object DeviceActionTools {

    private fun pStr(desc: String) = ParamPropertyPayload("STRING", desc)
    private fun pInt(desc: String) = ParamPropertyPayload("INTEGER", desc)
    private fun pBool(desc: String) = ParamPropertyPayload("BOOLEAN", desc)

    private fun fn(
        name: String,
        description: String,
        props: Map<String, ParamPropertyPayload> = emptyMap(),
        required: List<String> = emptyList()
    ) = FunctionDeclarationPayload(
        name = name,
        description = description,
        parameters = if (props.isEmpty()) null else ParametersPayload(
            properties = props,
            required = if (required.isEmpty()) null else required
        )
    )

    val tool: ToolPayload = ToolPayload(
        functionDeclarations = listOf(
            fn(
                "open_app",
                "Opens an installed app on the phone by its name, e.g. WhatsApp, YouTube, Chrome, Instagram, Camera, Settings.",
                mapOf("app_name" to pStr("Name of the app as the user says it, in English letters.")),
                listOf("app_name")
            ),
            fn(
                "call_contact",
                "Calls a person from the user's contacts, or dials a phone number.",
                mapOf("name_or_number" to pStr("Contact name written in English letters exactly as it would be saved (e.g. Mummy, Rahul), or a phone number.")),
                listOf("name_or_number")
            ),
            fn(
                "send_whatsapp",
                "Opens a WhatsApp chat with the message already typed. The user must press send themselves.",
                mapOf(
                    "name_or_number" to pStr("Contact name in English letters, or a phone number."),
                    "message" to pStr("The message text to type.")
                ),
                listOf("name_or_number", "message")
            ),
            fn(
                "send_sms",
                "Opens the SMS app with the message already typed. The user must press send themselves.",
                mapOf(
                    "name_or_number" to pStr("Contact name in English letters, or a phone number."),
                    "message" to pStr("The message text to type.")
                ),
                listOf("name_or_number", "message")
            ),
            fn(
                "set_alarm",
                "Sets an alarm at a specific time of day using the 24-hour clock.",
                mapOf(
                    "hour" to pInt("Hour in 24-hour format, 0 to 23."),
                    "minute" to pInt("Minute, 0 to 59."),
                    "label" to pStr("Optional label for the alarm.")
                ),
                listOf("hour", "minute")
            ),
            fn(
                "set_timer",
                "Starts a countdown timer.",
                mapOf(
                    "seconds" to pInt("Total timer length in seconds."),
                    "label" to pStr("Optional label for the timer.")
                ),
                listOf("seconds")
            ),
            fn(
                "flashlight",
                "Turns the phone flashlight (torch) on or off.",
                mapOf("on" to pBool("true to turn on, false to turn off.")),
                listOf("on")
            ),
            fn(
                "set_volume",
                "Changes the media volume.",
                mapOf(
                    "action" to pStr("One of: up, down, mute, max, set."),
                    "percent" to pInt("Volume percent 0-100. Only used when action is set.")
                ),
                listOf("action")
            ),
            fn(
                "play_youtube",
                "Searches YouTube for a video or song and opens the results.",
                mapOf("query" to pStr("What to search for on YouTube.")),
                listOf("query")
            ),
            fn(
                "web_search",
                "Searches Google in the browser.",
                mapOf("query" to pStr("What to search for.")),
                listOf("query")
            ),
            fn(
                "navigate_maps",
                "Shows a place in Google Maps, or starts navigation to it.",
                mapOf(
                    "place" to pStr("Place name or address."),
                    "start_navigation" to pBool("true to start turn-by-turn navigation, false to only show on the map.")
                ),
                listOf("place")
            ),
            fn(
                "open_settings",
                "Opens a phone settings screen. It cannot flip switches by itself, only opens the screen.",
                mapOf("screen" to pStr("One of: wifi, bluetooth, display, sound, battery, location, airplane, developer, apps, storage, accessibility, main.")),
                listOf("screen")
            ),
            fn("open_camera", "Opens the camera app."),
            fn("battery_status", "Tells the current battery percentage and whether the phone is charging."),
            fn("go_home", "Goes to the phone's home screen."),
            fn(
                "read_screen",
                "Reads the text, buttons and input fields currently visible on the phone screen. Call it after opening an app and after each action to see what is on screen. Needs Accessibility access."
            ),
            fn(
                "click_on",
                "Taps a button, link, tab or item on the current screen whose visible text or label matches the given text. Always call read_screen first so you know the exact label. Needs Accessibility access.",
                mapOf("text" to pStr("Visible text or label of the item to tap.")),
                listOf("text")
            ),
            fn(
                "type_text",
                "Types text into the currently focused input field, or the first input field on the screen. Needs Accessibility access.",
                mapOf("text" to pStr("Text to type.")),
                listOf("text")
            ),
            fn(
                "scroll_screen",
                "Scrolls the current screen. Needs Accessibility access.",
                mapOf("direction" to pStr("down (see more below) or up.")),
                listOf("direction")
            ),
            fn(
                "press_key",
                "Presses a system key. Needs Accessibility access (except home).",
                mapOf("key" to pStr("One of: back, home, recents, notifications, quick_settings, enter.")),
                listOf("key")
            ),
            fn(
                "open_accessibility_settings",
                "Opens the Accessibility settings screen so the user can turn on AJ'S JARVIS control. Use when screen-control tools say Accessibility is off."
            )
        )
    )
}
