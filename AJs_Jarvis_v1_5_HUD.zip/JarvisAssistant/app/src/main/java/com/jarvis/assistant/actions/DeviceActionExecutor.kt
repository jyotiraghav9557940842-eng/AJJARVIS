package com.jarvis.assistant.actions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.google.gson.JsonObject
import com.jarvis.assistant.automation.accessibility.JarvisAccessibilityService

/**
 * Runs the phone actions Gemini asks for through function calling.
 * Every function returns a short plain-text result that is sent back to the model.
 */
class DeviceActionExecutor(private val context: Context) {

    fun execute(name: String, args: JsonObject): String {
        return try {
            when (name) {
                "open_app" -> openApp(args.str("app_name"))
                "call_contact" -> callContact(args.str("name_or_number"))
                "send_whatsapp" -> sendWhatsApp(args.str("name_or_number"), args.str("message"))
                "send_sms" -> sendSms(args.str("name_or_number"), args.str("message"))
                "set_alarm" -> setAlarm(args.intOr("hour", -1), args.intOr("minute", 0), args.str("label"))
                "set_timer" -> setTimer(args.intOr("seconds", 0), args.str("label"))
                "flashlight" -> flashlight(args.boolOr("on", true))
                "set_volume" -> setVolume(args.str("action"), args.intOr("percent", -1))
                "play_youtube" -> playYouTube(args.str("query"))
                "web_search" -> webSearch(args.str("query"))
                "navigate_maps" -> navigateMaps(args.str("place"), args.boolOr("start_navigation", false))
                "open_settings" -> openSettings(args.str("screen"))
                "open_camera" -> openCamera()
                "battery_status" -> batteryStatus()
                "go_home" -> goHome()
                "read_screen" -> readScreen()
                "click_on" -> clickOn(args.str("text"))
                "type_text" -> typeText(args.str("text"))
                "scroll_screen" -> scrollScreen(args.str("direction"))
                "press_key" -> pressKey(args.str("key"))
                "open_accessibility_settings" -> openSettings("accessibility")
                else -> "Unknown action: $name"
            }
        } catch (e: Exception) {
            "Action failed: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    // ---------- small helpers ----------

    private fun JsonObject.str(key: String): String =
        if (has(key) && !get(key).isJsonNull) get(key).asString.trim() else ""

    private fun JsonObject.intOr(key: String, def: Int): Int = try {
        if (has(key) && !get(key).isJsonNull) get(key).asDouble.toInt() else def
    } catch (e: Exception) {
        def
    }

    private fun JsonObject.boolOr(key: String, def: Boolean): Boolean = try {
        if (has(key) && !get(key).isJsonNull) get(key).asBoolean else def
    } catch (e: Exception) {
        def
    }

    private fun has(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    private fun start(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }

    private fun startFirstAvailable(intents: List<Intent>): Boolean {
        for (i in intents) {
            if (start(i)) return true
        }
        return false
    }

    private fun normalize(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    // ---------- apps ----------

    private val appAliases = mapOf(
        "insta" to "instagram",
        "fb" to "facebook",
        "yt" to "youtube",
        "whatsap" to "whatsapp",
        "gmail" to "gmail",
        "chromebrowser" to "chrome"
    )

    private fun openApp(appName: String): String {
        if (appName.isBlank()) return "No app name was given."
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        var target = normalize(appName)
        target = appAliases[target] ?: target

        var bestPkg: String? = null
        var bestLabel = ""
        var bestScore = 0
        for (ri in apps) {
            val pkg = ri.activityInfo.packageName
            if (pkg == context.packageName) continue
            val label = normalize(ri.loadLabel(pm).toString())
            if (label.isEmpty()) continue
            val score = when {
                label == target -> 4
                label.startsWith(target) -> 3
                label.contains(target) -> 2
                label.length >= 3 && target.contains(label) -> 1
                else -> 0
            }
            if (score > bestScore || (score == bestScore && score > 0 && label.length < bestLabel.length)) {
                bestScore = score
                bestPkg = pkg
                bestLabel = label
            }
        }
        val pkg = bestPkg ?: return "No installed app matches '$appName'."
        val launch = pm.getLaunchIntentForPackage(pkg) ?: return "Could not open '$appName'."
        return if (start(launch)) "Opened $appName." else "Could not open '$appName'."
    }

    // ---------- calls / messages ----------

    private data class Resolved(val number: String, val name: String?)

    private fun looksLikeNumber(q: String) = q.any { it.isDigit() } && q.none { it.isLetter() }

    private fun resolveContact(query: String): Resolved? {
        val q = query.trim()
        if (q.isEmpty()) return null
        if (looksLikeNumber(q)) return Resolved(q.filter { it.isDigit() || it == '+' }, null)
        if (!has(Manifest.permission.READ_CONTACTS)) return null

        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val cols = arrayOf(
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        )
        val sel = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val cursor = context.contentResolver.query(uri, cols, sel, arrayOf("%$q%"), null) ?: return null
        var best: Resolved? = null
        cursor.use { c ->
            while (c.moveToNext()) {
                val number = c.getString(0) ?: continue
                val display = c.getString(1) ?: ""
                val r = Resolved(number, display)
                if (display.equals(q, ignoreCase = true)) {
                    best = r
                    break
                }
                if (best == null) best = r
            }
        }
        return best
    }

    private fun noContactMessage(query: String): String =
        if (!looksLikeNumber(query) && !has(Manifest.permission.READ_CONTACTS)) {
            "Contacts permission is not granted, so '$query' cannot be looked up. Ask the user to allow Contacts permission for the app, or to say the phone number."
        } else {
            "No contact found matching '$query'."
        }

    private fun callContact(target: String): String {
        val r = resolveContact(target) ?: return noContactMessage(target)
        val uri = Uri.fromParts("tel", r.number, null)
        val canCall = has(Manifest.permission.CALL_PHONE)
        val intent = Intent(if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri)
        val who = r.name ?: r.number
        return if (start(intent)) {
            if (canCall) "Calling $who." else "Dialer opened for $who. The user has to press the call button because Phone permission is not granted."
        } else {
            "Could not start the call."
        }
    }

    private fun whatsAppNumber(raw: String): String {
        var digits = raw.filter { it.isDigit() }
        // Assumes Indian numbers when no country code is present.
        if (digits.length == 11 && digits.startsWith("0")) digits = digits.drop(1)
        if (digits.length == 10) digits = "91$digits"
        return digits
    }

    private fun sendWhatsApp(target: String, message: String): String {
        val r = resolveContact(target) ?: return noContactMessage(target)
        val num = whatsAppNumber(r.number)
        val uri = Uri.parse("https://wa.me/$num?text=${Uri.encode(message)}")
        val intents = listOf("com.whatsapp", "com.whatsapp.w4b", null).map { pkg ->
            val i = Intent(Intent.ACTION_VIEW, uri)
            if (pkg != null) i.setPackage(pkg)
            i
        }
        val who = r.name ?: r.number
        return if (startFirstAvailable(intents)) {
            "WhatsApp chat with $who is open with the message typed. The user must press send themselves. Do not say it was sent."
        } else {
            "Could not open WhatsApp."
        }
    }

    private fun sendSms(target: String, message: String): String {
        val r = resolveContact(target) ?: return noContactMessage(target)
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${r.number}"))
        intent.putExtra("sms_body", message)
        val who = r.name ?: r.number
        return if (start(intent)) {
            "SMS app is open for $who with the message typed. The user must press send themselves. Do not say it was sent."
        } else {
            "Could not open the SMS app."
        }
    }

    // ---------- alarm / timer ----------

    private fun setAlarm(hour: Int, minute: Int, label: String): String {
        if (hour !in 0..23 || minute !in 0..59) return "Invalid alarm time."
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label.isNotBlank()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        val hh = hour.toString().padStart(2, '0')
        val mm = minute.toString().padStart(2, '0')
        return if (start(i)) "Alarm set for $hh:$mm." else "Could not set the alarm."
    }

    private fun setTimer(seconds: Int, label: String): String {
        if (seconds <= 0 || seconds > 86400) return "Invalid timer length."
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label.isNotBlank()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        return if (start(i)) "Timer started for $seconds seconds." else "Could not start the timer."
    }

    // ---------- hardware ----------

    private fun flashlight(on: Boolean): String {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "This phone has no flashlight."
        cm.setTorchMode(id, on)
        return if (on) "Flashlight is on." else "Flashlight is off."
    }

    private fun setVolume(action: String, percent: Int): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val step = maxOf(1, max / 5)
        val target = when (action.lowercase()) {
            "up" -> minOf(max, cur + step)
            "down" -> maxOf(0, cur - step)
            "mute" -> 0
            "max" -> max
            "set" -> if (percent in 0..100) Math.round(max * percent / 100f) else return "Volume percent is missing."
            else -> return "Unknown volume action."
        }
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        return "Media volume is now ${(target * 100f / max).toInt()} percent."
    }

    private fun batteryStatus(): String {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        if (level < 0 || scale <= 0) return "Battery level is not available."
        val pct = level * 100 / scale
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        return "Battery is at $pct percent and ${if (charging) "charging" else "not charging"}."
    }

    // ---------- web / media / maps ----------

    private fun playYouTube(query: String): String {
        if (query.isBlank()) return "No search text was given."
        val uri = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
        val intents = listOf("com.google.android.youtube", null).map { pkg ->
            val i = Intent(Intent.ACTION_VIEW, uri)
            if (pkg != null) i.setPackage(pkg)
            i
        }
        return if (startFirstAvailable(intents)) "Opened YouTube results for $query." else "Could not open YouTube."
    }

    private fun webSearch(query: String): String {
        if (query.isBlank()) return "No search text was given."
        val uri = Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
        return if (start(Intent(Intent.ACTION_VIEW, uri))) "Opened Google search for $query." else "Could not open the browser."
    }

    private fun navigateMaps(place: String, navigate: Boolean): String {
        if (place.isBlank()) return "No place was given."
        val geo = Uri.parse("geo:0,0?q=${Uri.encode(place)}")
        val primary = if (navigate) Uri.parse("google.navigation:q=${Uri.encode(place)}") else geo
        val intents = listOf(
            Intent(Intent.ACTION_VIEW, primary).setPackage("com.google.android.apps.maps"),
            Intent(Intent.ACTION_VIEW, geo)
        )
        return if (startFirstAvailable(intents)) {
            if (navigate) "Navigation to $place started." else "Showing $place on the map."
        } else {
            "Could not open Maps."
        }
    }

    private fun openSettings(screen: String): String {
        val action = when (screen.lowercase()) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display", "brightness" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "developer" -> Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return if (start(Intent(action))) "Opened $screen settings." else "Could not open settings."
    }

    private fun openCamera(): String =
        if (start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))) "Camera opened." else "Could not open the camera."

    private fun goHome(): String {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return if (start(home)) "Went to the home screen." else "Could not go home."
    }

    // ---------- screen control (needs Accessibility) ----------

    private val notEnabled =
        "Accessibility access for AJ'S JARVIS is OFF, so screen control is not possible yet. " +
            "Tell the user to turn on AJ'S JARVIS in Accessibility settings, and call open_accessibility_settings."

    private fun readScreen(): String {
        val svc = JarvisAccessibilityService.instance ?: return notEnabled
        Thread.sleep(700)
        return svc.readScreen()
    }

    private fun clickOn(text: String): String {
        val svc = JarvisAccessibilityService.instance ?: return notEnabled
        if (text.isBlank()) return "No text was given."
        val result = svc.clickByText(text)
        Thread.sleep(400)
        return result
    }

    private fun typeText(text: String): String {
        val svc = JarvisAccessibilityService.instance ?: return notEnabled
        val result = svc.typeText(text)
        Thread.sleep(300)
        return result
    }

    private fun scrollScreen(direction: String): String {
        val svc = JarvisAccessibilityService.instance ?: return notEnabled
        val result = svc.scroll(forward = !direction.equals("up", ignoreCase = true))
        Thread.sleep(400)
        return result
    }

    private fun pressKey(key: String): String {
        if (key.equals("home", ignoreCase = true)) return goHome()
        val svc = JarvisAccessibilityService.instance ?: return notEnabled
        val result = svc.pressKey(key.lowercase())
        Thread.sleep(300)
        return result
    }
}
